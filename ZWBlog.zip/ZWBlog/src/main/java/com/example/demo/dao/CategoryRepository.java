package com.example.demo.dao;

import com.example.demo.po.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.awt.print.Pageable;
import java.util.List;

public interface CategoryRepository extends JpaRepository<Category, Long> {

    Category findByName(String name);


    //List<Category> findTop(Pageable pageable);

    @Query("select t from Category t")
    List<Category> findTop(org.springframework.data.domain.Pageable pageable);
}
