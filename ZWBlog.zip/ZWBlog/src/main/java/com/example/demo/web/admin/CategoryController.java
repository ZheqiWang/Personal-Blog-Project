package com.example.demo.web.admin;


import com.example.demo.po.Category;
import com.example.demo.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@RequestMapping("/admin")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/category")
    public String category(@PageableDefault(size = 5,sort = {"id"},direction = Sort.Direction.DESC) Pageable pageable,
                           Model model) {

        model.addAttribute("page", categoryService.listCategory(pageable));
        return "admin/category";

    }

    @GetMapping("category/input")
    public String input(Model model) {
        model.addAttribute("category", new Category());
        return "admin/category-publish";
    }

    @GetMapping("category/{id}/input")
    public String editInput(@PathVariable Long id, Model model) {
        model.addAttribute("category", categoryService.getCategory(id));
        return "admin/category-publish";
    }

    @PostMapping("/category")
    public String post(@Valid Category category, BindingResult result, RedirectAttributes attributes) {
        Category t = categoryService.getCategoryByName(category.getName());
        if (t != null) {
            //name already exist
            result.rejectValue("name", "nameError", "This category already exist!");
        }

        if (result.hasErrors()) {
            return "admin/category-publish";
        }

        Category category1 = categoryService.saveCategory(category);
        if(category1 == null) {
            //save failed
            attributes.addFlashAttribute("message","Added Failed!");
        } else {
            //save success
            attributes.addFlashAttribute("message","Added Success!");
        }
        return "redirect:/admin/category";
    }

    @PostMapping("/category/{id}")
    public String editPost(@Valid Category category, BindingResult result, @PathVariable Long id, RedirectAttributes attributes) {
        Category t = categoryService.getCategoryByName(category.getName());
        if (t != null) {
            //name already exist
            result.rejectValue("name", "nameError", "This category already exist!");
        }

        if (result.hasErrors()) {
            return "admin/category-publish";
        }

        Category category1 = categoryService.updateCategory(id, category);
        if(category1 == null) {
            //save failed
            attributes.addFlashAttribute("message","Update Failed!");
        } else {
            //save success
            attributes.addFlashAttribute("message","Update Success!");
        }
        return "redirect:/admin/category";
    }

    @GetMapping("/category/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes attributes) {
        categoryService.deleteCategory(id);
        attributes.addFlashAttribute("message","Delete Success!");
        return "redirect:/admin/category";
    }

}
