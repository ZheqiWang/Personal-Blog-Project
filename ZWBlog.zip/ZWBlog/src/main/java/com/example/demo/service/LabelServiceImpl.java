package com.example.demo.service;

import com.example.demo.NotFoundException;
import com.example.demo.dao.LabelRepository;
import com.example.demo.po.Label;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
public class LabelServiceImpl implements LabelService {

    @Autowired
    private LabelRepository labelRepository;

    @Transactional
    @Override
    public Label saveLabel(Label label) {
        return labelRepository.save(label);
    }

    @Transactional
    @Override
    public Label getLabel(Long id) {
        return labelRepository.getOne(id);
    }

    @Override
    public Label getLabelByName(String name) {
        return labelRepository.findByName(name);
    }

    @Transactional
    @Override
    public Page<Label> listLabel(Pageable pageable) {
        return labelRepository.findAll(pageable);
    }

    @Override
    public List<Label> listLabel() {
        return labelRepository.findAll();
    }

    @Override
    public List<Label> listLabel(String ids) {
        //1,2,3
        return labelRepository.findAllById(convertToList(ids));
    }

    @Override
    public List<Label> listLabelTop(Integer size) {
        Sort sort = Sort.by(Sort.Direction.DESC,"blogs.size");
        Pageable pageable = PageRequest.of(0, size, sort);
        return labelRepository.findTop(pageable);
    }

    private List<Long> convertToList(String ids) {
        List<Long> list = new ArrayList<>();
        if (!"".equals(ids) && ids != null) {
            String[] idarray = ids.split(",");
            for (int i=0; i < idarray.length;i++) {
                list.add(new Long(idarray[i]));
            }
        }
        return list;
    }

    @Transactional
    @Override
    public Label updateLabel(Long id, Label label) {
        Label t = labelRepository.getOne(id);
        if (t == null) {
            throw new NotFoundException("The Label doesn't exist.");
        }
        BeanUtils.copyProperties(label,t);
        return labelRepository.save(t);
    }

    @Transactional
    @Override
    public void deleteLabel(Long id) {
        labelRepository.deleteById(id);
    }
}
