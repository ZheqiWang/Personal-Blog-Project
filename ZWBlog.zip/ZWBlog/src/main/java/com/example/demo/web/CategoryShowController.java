package com.example.demo.web;

import com.example.demo.po.Category;
import com.example.demo.service.BlogService;
import com.example.demo.service.CategoryService;
import com.example.demo.vo.BlogQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;


//spring boot不可以有同名的两个类存在（不同文件夹也不可以）
@Controller
public class CategoryShowController {

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private BlogService blogService;

    @GetMapping("/category/{id}")
    public String category(@PageableDefault(size = 8, sort = {"updateTime"}, direction = Sort.Direction.DESC) Pageable pageable,
                           @PathVariable Long id, Model model) {
        List<Category> categories = categoryService.listCategoryTop(10000);
        if (id == -1) {
            id = categories.get(0).getId();
        }
        BlogQuery blogQuery = new BlogQuery();
        blogQuery.setCategoryId(id);
        model.addAttribute("category", categories);
        model.addAttribute("page",blogService.listBlog(pageable,blogQuery));
        model.addAttribute("activeCategoryId",id);
        return "category";
    }
}
