package com.example.demo.web.admin;


import com.example.demo.po.Label;
import com.example.demo.service.LabelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@RequestMapping("/admin")
public class LabelController {

    @Autowired
    private LabelService labelService;

    @GetMapping("/label")
    public String label(@PageableDefault(size = 5,sort = {"id"},direction = Sort.Direction.DESC) Pageable pageable,
                           Model model) {

        model.addAttribute("page", labelService.listLabel(pageable));
        return "admin/label";

    }

    @GetMapping("label/input")
    public String input(Model model) {
        model.addAttribute("label", new Label());
        return "admin/label-publish";
    }

    @GetMapping("label/{id}/input")
    public String editInput(@PathVariable Long id, Model model) {
        model.addAttribute("label", labelService.getLabel(id));
        return "admin/label-publish";
    }

    @PostMapping("/label")
    public String post(@Valid Label label, BindingResult result, RedirectAttributes attributes) {
        Label t = labelService.getLabelByName(label.getName());
        if (t != null) {
            //name already exist
            result.rejectValue("name", "nameError", "This Label already exist!");
        }

        if (result.hasErrors()) {
            return "admin/label-publish";
        }

        Label label1 = labelService.saveLabel(label);
        if(label1 == null) {
            //save failed
            attributes.addFlashAttribute("message","Added Failed!");
        } else {
            //save success
            attributes.addFlashAttribute("message","Added Success!");
        }
        return "redirect:/admin/label";
    }

    @PostMapping("/label/{id}")
    public String editPost(@Valid Label label, BindingResult result, @PathVariable Long id, RedirectAttributes attributes) {
        Label t = labelService.getLabelByName(label.getName());
        if (t != null) {
            //name already exist
            result.rejectValue("name", "nameError", "This label already exist!");
        }

        if (result.hasErrors()) {
            return "admin/label-publish";
        }

        Label label1 = labelService.updateLabel(id, label);
        if(label1 == null) {
            //save failed
            attributes.addFlashAttribute("message","Update Failed!");
        } else {
            //save success
            attributes.addFlashAttribute("message","Update Success!");
        }
        return "redirect:/admin/label";
    }

    @GetMapping("/label/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes attributes) {
        labelService.deleteLabel(id);
        attributes.addFlashAttribute("message","Delete Success!");
        return "redirect:/admin/label";
    }

}
