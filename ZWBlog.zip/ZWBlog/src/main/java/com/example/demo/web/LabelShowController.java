package com.example.demo.web;

import com.example.demo.po.Label;
import com.example.demo.service.BlogService;
import com.example.demo.service.LabelService;
import com.example.demo.service.LabelService;
import com.example.demo.vo.BlogQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;


//spring boot不可以有同名的两个类存在（不同文件夹也不可以）
@Controller
public class LabelShowController {

    @Autowired
    private LabelService labelService;

    @Autowired
    private BlogService blogService;

    @GetMapping("/label/{id}")
    public String Label(@PageableDefault(size = 8, sort = {"updateTime"}, direction = Sort.Direction.DESC) Pageable pageable,
                           @PathVariable Long id, Model model) {
        List<Label> labels = labelService.listLabelTop(10000);
        if (id == -1) {
            id = labels.get(0).getId();
        }
        model.addAttribute("label", labels);
        model.addAttribute("page",blogService.listBlog(id, pageable));
        model.addAttribute("activeLabelId",id);
        return "label";
    }
}
