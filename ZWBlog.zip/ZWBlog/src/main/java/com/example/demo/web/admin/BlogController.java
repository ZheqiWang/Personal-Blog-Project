package com.example.demo.web.admin;

import com.example.demo.po.Blog;
import com.example.demo.po.User;
import com.example.demo.service.BlogService;
import com.example.demo.service.BlogServiceImpl;
import com.example.demo.service.CategoryService;
import com.example.demo.service.LabelService;
import com.example.demo.vo.BlogQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class BlogController {

    private static final String INPUT = "admin/blogpublish";
    private static final String LIST = "admin/blogmanage";
    private static final String REDIRECT_LIST = "redirect:/admin/blogmanage";

    @Autowired
    private BlogService blogService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private LabelService labelService;

    public BlogController() {
    }


    @GetMapping("/blogmanage")
    public String blogs(@PageableDefault(size = 8, sort = {"updateTime"}, direction = Sort.Direction.DESC) Pageable pageable,
                        BlogQuery blog, Model model) {
        model.addAttribute("category", categoryService.listCategory());
        model.addAttribute("page", blogService.listBlog(pageable, blog));
        return LIST;
    }

    @PostMapping("/blogmanage/search")
    public String search(@PageableDefault(size = 8, sort = {"updateTime"}, direction = Sort.Direction.DESC) Pageable pageable, BlogQuery blog, Model model) {
        model.addAttribute("page", blogService.listBlog(pageable, blog));
        return "admin/blogmanage :: blogList";
    }

    @GetMapping("/blogpublish")
    public String input(Model model) {
        setCategoryAndLabel(model);
        model.addAttribute("blog", new Blog());
        return INPUT;
    }

    private void setCategoryAndLabel(Model model){
        model.addAttribute("category", categoryService.listCategory());
        model.addAttribute("label", labelService.listLabel());
    }

    @GetMapping("/blogmanage/{id}/input")
    public String editInput(@PathVariable Long id, Model model) {
        setCategoryAndLabel(model);
        Blog blog = blogService.getBlog(id);
        blog.init();
        model.addAttribute("blog", blog);
        return INPUT;
    }

    @PostMapping("/blogmanage")
    public String post(Blog blog, RedirectAttributes attributes, HttpSession session) {
        blog.setUser((User) session.getAttribute("user"));
        blog.setCategory(categoryService.getCategory(blog.getCategory().getId()));
        blog.setLabels(labelService.listLabel(blog.getLabelIds()));
        Blog b;
        if (blog.getId() == null) {
            b = blogService.saveBlog(blog);
        } else {
            b = blogService.updateBlog(blog.getId(), blog);
        }

        if(b == null) {
            //save failed
            attributes.addFlashAttribute("message","Operation Failed!");
        } else {
            //save success
            attributes.addFlashAttribute("message","Operation Success!");
        }

        return REDIRECT_LIST;
    }

    @GetMapping("blogmanage/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes attributes) {
        blogService.deleteBlog(id);
        attributes.addFlashAttribute("message","Delete Success!");
        return REDIRECT_LIST;
    }
}
