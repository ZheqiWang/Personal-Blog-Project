package com.example.demo.dao;

import com.example.demo.po.Label;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.awt.print.Pageable;
import java.util.List;

public interface LabelRepository extends JpaRepository<Label, Long> {

    Label findByName(String name);

    @Query("select t from Label t")
    List<Label> findTop(org.springframework.data.domain.Pageable pageable);
}
